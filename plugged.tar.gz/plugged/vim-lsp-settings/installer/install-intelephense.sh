#!/usr/bin/env bash

set -e

"$(dirname "$0")/npm_install.sh" intelephense intelephense
