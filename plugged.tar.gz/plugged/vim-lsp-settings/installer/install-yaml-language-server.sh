#!/usr/bin/env bash

set -e

"$(dirname "$0")/yarn_install.sh" yaml-language-server yaml-language-server
