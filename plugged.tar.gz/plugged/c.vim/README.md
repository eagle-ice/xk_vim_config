# 修改一下c的coding style

```
if () {
}
```

```
do {
} while();
```


